#Lab4 - ECE 420

To run:

In a terminal

Compile command:
> make all

To run the MPI version:
> make run

To run the serial version:
> make run_serial

To cleanup the files:
> make clean



