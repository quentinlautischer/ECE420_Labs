#Lab2 - ECE 420


To run:

In a terminal

Compile command:
> make all

Start server:
> make run_server

Start client:
> make run_client 
